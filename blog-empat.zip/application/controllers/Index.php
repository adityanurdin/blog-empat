<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
    $this->load->model('Model_artikel');
    // $this->load->library('email');
  }

  function index()
  {
    // $this->load->view('Home/home');
    $this->load->library('pagination');

    $config['base_url'] = base_url().'index/index/';
    $config['total_rows'] = $this->Model_artikel->tampil_data()->num_rows();
    $config['per_page'] = 3;

    $this->pagination->initialize($config);

    $data['paging'] =  $this->pagination->create_links();

    $halaman = $this->uri->segment(3);
    $halaman = $halaman==''?0:$halaman;
    $data['record'] = $this->Model_artikel->paging($halaman)->result();
    // $data['pengumuman'] = $this->Model_artikel->tampil_data_pengumuman()->result();
    $this->template->load('template','Home/home' , $data);
    // $this->load->view('template' , $data);
  }

  function detail()
  {
    $id = $this->uri->segment(3);
    $data['record'] = $this->Model_artikel->get_one($id)->row_array();
    // $this->load->view('Home/detail.php' , $data);
    $this->template->load('template' , 'Home/detail' , $data);
  }

  // function email()
  // {
  //   if (isset($_POST['submit'])) {
  //
  //     $email = $this->input->post('email');
  //     $data = array('email' => $email);
  //     $this->email->to('adityanurdin0@gmail.com');
  //     $this->email->from('admin@adityanurdin.com' , 'Adityanurdin.com');
  //     $this->email->subject('Welcome to Adityanurdin.com');
  //     $this->email->message('Terimakasih telah mensubsribe blog gue kawan, tunggu cerita-cerita dari gue ya..');
  //     $this->email->send();
  //     redirect('Index');
  //   }else {
  //     redirect('qqq');
  //   }
  // }


  function email()
  {
    if (isset($_POST['submit'])) {
      $email = $this->input->post('email');
      $tanggal_email = $this->input->post('tanggal_email');
      $data = array('email' => $email,
                    'tanggal_email' => $tanggal_email);
      $this->Model_artikel->email($data);
      redirect('Index');
    }else{
      $this->template->load('template' , 'Home/index');
    }
  }

  function about()
  {
    $this->template->load('template' , 'Home/about');
  }
  function tutorial_tkj()
  {
    // $this->load->view('Home/home');
    $this->load->library('pagination');

    $config['base_url'] = base_url().'index/index/';
    $config['total_rows'] = $this->Model_artikel->tampil_data()->num_rows();
    $config['per_page'] = 3;

    $this->pagination->initialize($config);

    $data['paging'] =  $this->pagination->create_links();

    $halaman = $this->uri->segment(3);
    $halaman = $halaman==''?0:$halaman;
    $data['record'] = $this->Model_artikel->paging($halaman)->result();
    // $data['pengumuman'] = $this->Model_artikel->tampil_data_pengumuman()->result();
    $this->template->load('template' , 'Home/tutorial_tkj' , $data);
    // $this->load->view('template' , $data);
  }
  // public function search()
  // {
  //   $keyword = $this->input->post('keyword');
  //   $artikel = $this->Model_artikel->search($keyword);
  //   $hasil = $this->load->view()
  // }

}
