<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
    $this->load->model('Model_artikel');
    check_session();
  }

  function index()
  {
    // $this->load->view('Home/home');
    $data['user'] = $this->Model_artikel->user()->result();
    $data['record'] = $this->Model_artikel->tampil_data()->result();
    $this->template->load('template-dashboard','Dashboard/index' , $data);
  }

  function new_user()
  {

  }

  function new_post()
  {
    if (isset($_POST['submit'])) {
      $config['upload_path']          = './assets/images/foto_artikel/';
      $config['allowed_types']        = 'gif|jpg|png';
      $config['max_size']             = 1024;
      // $config['max_width']            = 1366;
      // $config['max_height']           = 768;
      $new_name = time().$_FILES["userfile"]['name'];
      $config['file_name'] = $new_name;
      $this->load->library('upload', $config);
      $this->upload->do_upload();
      $hasil = $this->upload->data();

      $judul_artikel    =   $this->input->post('judul_artikel');
      $isi_artikel      =   $this->input->post('isi_artikel');
      $kategori_artikel =   $this->input->post('kategori_artikel');
      $tanggal_artikel  =   $this->input->post('tanggal_artikel');
      $username         =   $this->input->post('username');
      $data             =   array('judul_artikel' => $judul_artikel,
                                'isi_artikel' => $isi_artikel,
                                'tanggal_artikel' => $tanggal_artikel,
                                'kategori_artikel' => $kategori_artikel,
                                'foto' => $hasil['file_name'],
                                'username' => $username);
      $this->Model_artikel->post($data);
      redirect('Dashboard');
    }else{
      $data['kategori'] = $this->Model_artikel->tampil_data_kategori()->result();
      $data['record'] = $this->Model_artikel->tampil_data()->result();
    $this->template->load('template-dashboard' , 'Admin/new_post' , $data);
    }
  }

  function detail()
  {
    $id = $this->uri->segment(3);
    $data['record'] = $this->Model_artikel->get_one($id)->row_array();
    // $this->load->view('Home/detail.php' , $data);
    $this->template->load('template-dashboard' , 'Dashboard/detail-post' , $data);
  }

  function delete_post()
  {
    $id = $this->uri->segment(3);
    $this->Model_artikel->delete($id);
    redirect('Dashboard/delete_page');
  }

  function delete_page()
  {
    $data['record'] = $this->Model_artikel->tampil_data()->result();
    $this->template->load('template-dashboard' , 'Admin/delete_post' , $data);
  }

  function edit_page()
  {
    $data['record'] = $this->Model_artikel->tampil_data()->result();
    $this->template->load('template-dashboard' , 'Admin/edit_post' , $data);
  }

  function edit_post()
  {
    if (isset($_POST['submit'])) {
      $id_artikel       =   $this->input->post('id_artikel');
      $judul_artikel     =   $this->input->post('judul_artikel');
      $kategori_artikel =   $this->input->post('kategori_artikel');
      $isi_artikel    =   $this->input->post('isi_artikel');
      $data     = array('judul_artikel' => $judul_artikel,
                        'kategori_artikel' => $kategori_artikel,
                        'isi_artikel' => $isi_artikel);
      $this->Model_artikel->edit($data , $id_artikel);
      redirect('Dashboard/edit_page');
    }else {
      $id = $this->uri->segment(3);
      $data['kategori'] = $this->Model_artikel->tampil_data_kategori()->result();
      $data['record'] = $this->Model_artikel->get_one($id)->row_array();
      $this->template->load('template-dashboard' , 'Admin/edit' , $data);
    }

  }
  function delete_all()
  {
    if (isset($_POST['submit'])) {
      $this->db->empty_table('artikel');
      redirect('Dashboard/index');
    }
  }
  function genre()
  {
    if (isset($_POST['submit'])) {
      $kategori = $this->input->post('kategori');
      $data = array('kategori' => $kategori);
      $this->Model_artikel->genre($data);
      redirect('Dashboard/genre');
    }else {
      $data['record'] = $this->Model_artikel->tampil_data_kategori()->result();
      $this->template->load('template-dashboard' , 'Admin/genre' , $data);
    }
  }
  // function delete_genre()
  // {
  //   $id = $this->uri->segment(3);
  //   $this->Model_artikel->delete($id);
  //   redirect('Dashboard/delete_page');
  // }
  function pengumuman()
  {
      if (isset($_POST['submit'])) {
      $pengumuman = $this->input->post('pengumuman');
      $tgl_pengumuman = $this->input->post('tgl_pengumuman');
      $data = array('pengumuman' => $pengumuman,
                    'tgl_pengumuman' => $tgl_pengumuman);
      $this->Model_artikel->pengumuman($data);
      redirect('Dashboard/pengumuman');
    }else {
      $data['record'] = $this->Model_artikel->tampil_data_pengumuman()->result();
      $this->template->load('template-dashboard' , 'Admin/pengumuman' , $data);
    }
  }

}
