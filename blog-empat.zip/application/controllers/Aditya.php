<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Aditya extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
    $this->load->model('Model_aditya');
  }

  function index()
  {
    redirect('Aditya/login');
  }

  function login()
  {
    if(isset($_POST['submit'])) {

      $username = $this->input->post('username');
      $password = $this->input->post('password');
      $type_admin = $this->input->post('type_admin');
      $last_login = $this->input->post('last_login');
      $hasil  = $this->Model_aditya->login($username , $password , $type_admin);
      if ($hasil == 1) {
        $this->db->where('username' , $username);
        $this->db->update('aditya' , array('last_login' => date('Y-m-d h:i:s')));
        $this->session->set_userdata(array('status_login'=>'oke',
                                           'username' => $username,
                                           'type_admin' => $type_admin,
                                           'last_login' => $last_login
                                           ));
        redirect('Dashboard');
      }else {
        redirect('Aditya/login');
      }
    }
    else
    {
      check_session_login();
      $this->load->view('Admin/login');
    }
  }

  function logout()
  {
    $this->session->sess_destroy();
    redirect('Aditya/login');
  }


}
