<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_aditya extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function login($username , $password , $type_admin)
  {
    $check = $this->db->get_where('aditya' , array('username' => $username , 'password' => md5($password) , 'type_admin' => $type_admin));
    if ($check->num_rows()>0){
        return 1;
    }else{
        return 0;
    }
  }

}
