<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_artikel extends CI_Model{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

  function tampil_data()
  {
    // return $this->db->get('artikel');
    $this->db->order_by('tanggal_artikel', 'DESC');
    $query = $this->db->get('artikel');
    return $query;
  }
  function user()
  {
    return $this->db->get('aditya');
  }

  function post($data)
  {
    // proses input
    $this->db->insert('artikel',$data);
  }

  function get_one($id)
  {
    $key = '123d3ct012';
    $param = array('md5(id_artikel)' => $id);
    return $this->db->get_where('artikel' , $param);
  }

  function delete($id)
  {
    $this->db->where('id_artikel' , $id);
    $query = $this->db->get('artikel');
    $row = $query->row();
    unlink("./assets/images/foto_artikel/$row->foto");
    $this->db->delete('artikel', array('id_artikel' => $id));
  }

  function edit($data , $id_artikel)
  {
    $this->db->where('id_artikel' , $id_artikel);
    $this->db->update('artikel' , $data);
  }

  function paging($halaman)
  {
     // $query =  $this->db->query("select * from artikel limit $halaman,3");
     // return $query;
     $this->db->order_by('tanggal_artikel' , 'desc');
     $data = $this->db->get('artikel' , 3 , $halaman);
     return $data;

  }

  function tampil_data_kategori()
  {
    // return $this->db->get('artikel');
    // $this->db->order_by('tanggal_artikel', 'DESC');
    $query = $this->db->get('kategori');
    return $query;
  }

  function genre($data)
  {
    // proses input
    $this->db->insert('kategori',$data);
  }

  function email($data)
  {
    $this->db->insert('email' , $data);
  }
  function pengumuman($data)
  {
    // proses input
    $this->db->insert('pengumuman',$data);
  }
  function tampil_data_pengumuman()
  {
    // return $this->db->get('artikel');
    // $this->db->order_by('tanggal_artikel', 'DESC');
    $query = $this->db->get('pengumuman');
    return $query;
  }
  // function search($keyword){
  //   $this->db->like('judul_artikel' , $keyword);
  //   $this->db->or_like('isi_artikel' , $keyword);
  //   $this->db->or_like('tanggal_artikel' , $keyword);
  //   $result = $this->db->get('artikel')->result();
  //   return $result;
  // }

}
