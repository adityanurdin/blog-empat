<?php
date_default_timezone_set('Asia/Jakarta');
$date = date('Y-m-d h:i:s');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <link rel='shortcut icon' type='image/x-icon' href="<?= base_url(); ?>assets/images/ico.ico" />
  <title>Blog Empat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?= base_url(); ?>assets/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
  <script src="<?= base_url(); ?>assets/js/bootstrap.min.js"></script>
  <script src="<?= base_url(); ?>assets/js/jquery.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      font: 400 15px Lato, sans-serif;
      line-height: 1.8;
      color: #818181;
  }
  h1 {
    font-size: 24px;
    text-transform: uppercase;
    color: #303030;
    font-weight: 600;
    margin-bottom: 30px;
    }
  h2 {
      font-size: 24px;
      text-transform: uppercase;
      color: #303030;
      font-weight: 600;
      margin-bottom: 30px;
  }
  h4 {
      font-size: 19px;
      line-height: 1.375em;
      color: #303030;
      font-weight: 400;
      margin-bottom: 30px;
  }
  .jumbotron {
      background-color:#ffffe6;
      color: #000000;
      padding: 100px 25px;
      font-family: Montserrat, sans-serif;
  }
  .container-fluid {
      padding: 60px 50px;
  }
  .bg-grey {
      background-color: #f6f6f6;
  }
  .logo-small {
      color: #f4511e;
      font-size: 50px;
  }
  .logo {
      color: #f4511e;
      font-size: 200px;
  }
  .thumbnail {
      padding: 0 0 15px 0;
      border: none;
      border-radius: 0;
  }
  .thumbnail img {
      width: 100%;
      height: 100%;
      margin-bottom: 10px;
  }
  .carousel-control.right, .carousel-control.left {
      background-image: none;
      color: #f4511e;
  }
  .carousel-indicators li {
      border-color: #f4511e;
  }
  .carousel-indicators li.active {
      background-color: #f4511e;
  }
  .item h4 {
      font-size: 19px;
      line-height: 1.375em;
      font-weight: 400;
      font-style: italic;
      margin: 70px 0;
  }
  .item span {
      font-style: normal;
  }
  .panel {
      border: 1px solid #f4511e;
      border-radius:0 !important;
      transition: box-shadow 0.5s;
  }
  .panel:hover {
      box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
      border: 1px solid #f4511e;
      background-color: #fff !important;
      color: #f4511e;
  }
  .panel-heading {
      color: #fff !important;
      background-color: #f4511e !important;
      padding: 25px;
      border-bottom: 1px solid transparent;
      border-top-left-radius: 0px;
      border-top-right-radius: 0px;
      border-bottom-left-radius: 0px;
      border-bottom-right-radius: 0px;
  }
  .panel-footer {
      background-color: white !important;
  }
  .panel-footer h3 {
      font-size: 32px;
  }
  .panel-footer h4 {
      color: #aaa;
      font-size: 14px;
  }
  .panel-footer .btn {
      margin: 15px 0;
      background-color: #f4511e;
      color: #fff;
  }
  .navbar {
      margin-bottom: 0;
      background-color: #5c8a8a;
      z-index: 9999;
      border: 0;
      font-size: 12px !important;
      line-height: 1.42857143 !important;
      letter-spacing: 4px;
      border-radius: 0;
      font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
      color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
      color: #f4511e !important;
      background-color: #d9d9d9 !important;
  }
  .navbar-default .navbar-toggle {
      border-color: transparent;
      color: #fff !important;
  }
  footer .glyphicon {
      font-size: 15px;
      margin-bottom: 20px;
      color: #f4511e;
  }
  .slideanim {visibility:hidden;}
  .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    }
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    }
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }
  @media screen and (max-width: 768px) {
    .col-sm-4 {
      text-align: center;
      margin: 25px 0;
    }
    .btn-lg {
        width: 100%;
        margin-bottom: 35px;
    }
  }
  @media screen and (max-width: 480px) {
    .logo {
        font-size: 150px;
    }
  }
  </style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
    <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.12';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?= base_url(); ?>">BLOG EMPAT</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?= base_url();?>">HOME <span class="glyphicon glyphicon-home"></span></a></li>
        <!-- <li><a href="#social">CATEGORY <span class="glyphicon glyphicon-tasks"></span></a></li> -->
        <!-- <li><a href="#social">FOLLOW ME <span class="glyphicon glyphicon-heart"></span></a></li> -->
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">TUTORIAL <span class="glyphicon glyphicon-info-sign"></span>
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="<?= base_url();?>Index/tutorial_tkj"><font color="black">TKJ <span class="glyphicon glyphicon-signal"></span></font></a></li>
          <li><a href="<?= base_url();?>Index/about"><font color="black">TBSM <span class="glyphicon glyphicon-cog"></span></font></a></li>
          <li><a href="<?= base_url();?>Index/abouts"><font color="black">PSPT <span class="glyphicon glyphicon-film"></span></font></a></li>
        </ul>
      </li>
    <li><a href="<?= base_url();?>Index/about">ABOUT <span class="glyphicon glyphicon-info-sign"></span></a></li>
      </ul>
    </div>
  </div>
</nav>
<br><br>
<body>
<div class="container">
    <!-- <div class="alert alert-success alert-dismissable fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <?php foreach ($pengumuman as $p) {
      echo "

      <div class='col-sm-10'><strong>$p->tgl_pengumuman</strong></div>$p->pengumuman

      ";
    }
    ?>
  </div> -->
  <h4><span class="label label-info"><small><font color="white">RECENT POSTS</font></small></span></h4>

<!--  <div id="myCarousel" class="carousel slide" data-ride="carousel">-->
  <!-- Indicators -->
<!--  <ol class="carousel-indicators">-->
<!--    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>-->
<!--    <li data-target="#myCarousel" data-slide-to="1"></li>-->
<!--    <li data-target="#myCarousel" data-slide-to="2"></li>-->
<!--  </ol>-->

  <!-- Wrapper for slides -->
<!--  <div class="carousel-inner">-->
<!--    <div class="item active">-->
<!--      <img src="https://blog-empat.000webhostapp.com/assets/images/foto_artikel/Slider-Website-1.jpg" alt="Los Angeles">-->
<!--    </div>-->

<!--    <div class="item">-->
<!--      <img src="https://blog-empat.000webhostapp.com/assets/images/foto_artikel/Slider-Website-1.jpg" alt="Chicago">-->
<!--    </div>-->
<!--    <div class="item">-->
<!--      <img src="https://blog-empat.000webhostapp.com/assets/images/foto_artikel/Slider-Website-1.jpg" alt="New York">-->
<!--    </div>-->
<!--  </div>-->
  <!-- Left and right controls -->
<!--  <a class="left carousel-control" href="#myCarousel" data-slide="prev">-->
<!--    <span class="glyphicon glyphicon-chevron-left"></span>-->
<!--    <span class="sr-only">Previous</span>-->
<!--  </a>-->
<!--  <a class="right carousel-control" href="#myCarousel" data-slide="next">-->
<!--    <span class="glyphicon glyphicon-chevron-right"></span>-->
<!--    <span class="sr-only">Next</span>-->
<!--  </a>-->
<!--</div>-->

<?php echo $contents; ?>

<table>
  <tr>
    <td>
<div class="col-sm-16">
  <hr>
  <h2> ME </h2>
  <p><img src="http://3.bp.blogspot.com/-EAjTVZPOEVI/UqE3jUS7brI/AAAAAAAAACc/wDC55JdZqe8/s1600/lOGO.JPG" class="img-circle" style="height : 115px; width : 115px;"></p>
  <div class="caption">
          <p>SMK NEGERI 4 BEKASI</p>
        </div>
  <hr>
  <h2>FOLLOW US</h2>
  <p><span class="glyphicon glyphicon-globe"></span> <a href="http://www.smkn4-kotabekasi.sch.id/" class="label label-success">WWW.SMKN4-KOTABEKASI.SCH.ID</a></p>
  <p><span class="glyphicon glyphicon-camera"></span> <a href="https://www.instagram.com/smkn4bekasiofficial/" class="label label-danger">INSTAGRAM</a></p>
  <p><span class="glyphicon glyphicon-thumbs-up"></span> <a href="https://web.facebook.com/groups/smk4bks/" class="label label-primary">FACEBOOK</a></p>
  <!-- <p><span class="glyphicon glyphicon-envelope"></span> <a href="sadsdasda" class="label label-success">LINE</a></p> -->
  <hr>
  <div>
     <!-- Start of shorte.st banner code -->
<a href="http://join-shortest.com/ref/9b0687ab34"><img src="https://static.shorte.st/bundles/smeuser/img/referral_banners/125x125.png?2018-02-21.0" title="Earn on short links" width="125" height="125" /></a>
<!-- End of shorte.st banner code -->
  </div>
  <div>
      <a href="http://khalifistore.com"><img src="http://i64.tinypic.com/fdyo8p.png" width="250" height="175"></a>
  </div> 
  <br>
  <!-- <h5><span class="label label-warning">have story? share here <span class="glyphicon glyphicon-open-file"></span></span></h5> -->
  <!-- <h4> Kritik & Saran</h4> -->
  <a href="" class="btn btn-primary">Criticism & Suggestions</a>
  <!-- <hr>
  <h2>SUBSCRIBE ME <span class="glyphicon glyphicon-envelope"></span></h2>
  <form <?= form_open('Index/email'); ?>
    <input type="text" name="tanggal_email" value="<?= $date ?>" hidden="">
    <input type="email" name="email" placeholder="Email">
    <input type="submit" value="submit" name="submit" class="btn btn-primary">
  </form> -->
</div>
</td>
</tr>
</table>
<!-- Buat Paging -->

<!-- <div class="col-sm-4">

</div> -->

</div>

<!--Start of Tawk.to Script-->

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5a8d51b4d7591465c707de65/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>

<!--End of Tawk.to Script-->

<script type='text/javascript'>
//<![CDATA[
var Nanobar=function(){var c,d,e,f,g,h,k={width:"100%",height:"2px",zIndex:9999,top:"0"},l={width:0,height:"100%",clear:"both",transition:"height .3s"};c=function(a,b){for(var c in b)a.style[c]=b[c];a.style["float"]="left"};f=function(){var a=this,b=this.width-this.here;0.1>b&&-0.1<b?(g.call(this,this.here),this.moving=!1,100==this.width&&(this.el.style.height=0,setTimeout(function(){a.cont.el.removeChild(a.el)},100))):(g.call(this,this.width-b/4),setTimeout(function(){a.go()},16))};g=function(a){this.width=
a;this.el.style.width=this.width+"%"};h=function(){var a=new d(this);this.bars.unshift(a)};d=function(a){this.el=document.createElement("div");this.el.style.backgroundColor=a.opts.bg;this.here=this.width=0;this.moving=!1;this.cont=a;c(this.el,l);a.el.appendChild(this.el)};d.prototype.go=function(a){a?(this.here=a,this.moving||(this.moving=!0,f.call(this))):this.moving&&f.call(this)};e=function(a){a=this.opts=a||{};var b;a.bg=a.bg||"#db3131";this.bars=[];b=this.el=document.createElement("div");c(this.el,
k);a.id&&(b.id=a.id);b.style.position=a.target?"relative":"fixed";a.target?a.target.insertBefore(b,a.target.firstChild):document.getElementsByTagName("body")[0].appendChild(b);h.call(this)};e.prototype.go=function(a){this.bars[0].go(a);100==a&&h.call(this)};return e}();
var nanobar = new Nanobar();nanobar.go(30);nanobar.go(60);nanobar.go(100);
//]]>
</script>
</body>
<br><br>
<footer class="text-center">
  <p>
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a></p>
  &copy; Aditya Nurdin <?php echo date('Y') ?>
</footer>
<script>
$(document).ready(function(){
  // Initialize Tooltip
  $('[data-toggle="tooltip"]').tooltip();
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();
      // Store hash
      var hash = this.hash;
      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
})
</script>
</html>
