<?php

echo "
<div class='col-sm-9'>
<br>
  <a  href='".base_url()."Dashboard/edit_post/".md5($record['id_artikel'])."' class='btn btn-warning'>Edit <span class='glyphicon glyphicon-edit'></span></a>
  <a  href='".base_url()."Dashboard/delete_post/".md5($record['id_artikel'])."' class='btn btn-danger'>Delete <span class='glyphicon glyphicon-remove'></span></a>
      <h2>".$record['judul_artikel']."</h2>
      <h5><span class='glyphicon glyphicon-time'></span> Post ".$record['tanggal_artikel']."</h5>
      <p>".$record['isi_artikel']."</p>
      <br><br>
      </div>

";
 ?>