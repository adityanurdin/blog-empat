<h3>Info User</h3>
<h5>Hallo <?php echo $this->session->userdata('username'); ?> </h5>
<h5>Type : <?php echo $this->session->userdata('type_admin'); ?> </h5>
<h5>Last Login : <?php echo $this->session->userdata('last_login'); ?> </h5>
<br><br>
<!-- <?php foreach ($record as $r) {
    echo '
    <div class="col-sm-9">
    <h2>'.$r->judul_artikel.'</h2>
    <h5><span class="glyphicon glyphicon-time"></span> Post '.$r->tanggal_artikel.'</h5>
    <img src="'.base_url().'assets/images/foto_artikel/'.$r->foto.'" class="img-responsive" width="300" height="175" ="Image">
    <p>'.substr($r->isi_artikel,0,100).'...</p>
    <a href="Dashboard/detail/'.md5($r->id_artikel).'" class="btn btn-primary btn-sm">Read more</a>
    <br><br>
    </div>


    ';
  }

?> -->

<?php
$type_admin = $this->session->userdata('type_admin');
if ($type_admin == "MASTER") {
  foreach ($record as $r) {
      echo '
      <div class="col-sm-9">
      <h2>'.$r->judul_artikel.'</h2>
      <h5><span class="glyphicon glyphicon-time"></span> Post '.$r->tanggal_artikel.'</h5>
      <img src="'.base_url().'assets/images/foto_artikel/'.$r->foto.'" class="img-responsive" width="300" height="175" ="Image">
      <p>'.substr($r->isi_artikel,0,100).'...</p>
      <p><strong>Genre</strong> : <span class="label label-success">'.$r->kategori_artikel.'</span></p>
      <a href="Dashboard/detail/'.md5($r->id_artikel).'" class="btn btn-primary btn-sm">Read more</a>
      <br><br>
      </div>
      ';
    }
}elseif ($type_admin == "ADMIN TKJ") {
  foreach ($record as $r) {
  if ($r->kategori_artikel == "Tutorial TKJ") {
      echo '
      <div class="col-sm-9">
      <h2>'.$r->judul_artikel.'</h2>
      <h5><span class="glyphicon glyphicon-time"></span> Post '.$r->tanggal_artikel.'</h5>
      <img src="'.base_url().'assets/images/foto_artikel/'.$r->foto.'" class="img-responsive" width="300" height="175" ="Image">
      <p>'.substr($r->isi_artikel,0,100).'...</p>
      <p><strong>Genre</strong> : <span class="label label-success">'.$r->kategori_artikel.'</span></p>
      <a href="Dashboard/detail/'.md5($r->id_artikel).'" class="btn btn-primary btn-sm">Read more</a>
      <br><br>
      </div>
      ';
    }
  }
}elseif ($type_admin == "ADMIN TSM") {
  foreach ($record as $r) {
  if ($r->kategori_artikel == "Tutorial TSM") {
      echo '
      <div class="col-sm-9">
      <h2>'.$r->judul_artikel.'</h2>
      <h5><span class="glyphicon glyphicon-time"></span> Post '.$r->tanggal_artikel.'</h5>
      <img src="'.base_url().'assets/images/foto_artikel/'.$r->foto.'" class="img-responsive" width="300" height="175" ="Image">
      <p>'.substr($r->isi_artikel,0,100).'...</p>
      <p><strong>Genre</strong> : <span class="label label-success">'.$r->kategori_artikel.'</span></p>
      <a href="Dashboard/detail/'.md5($r->id_artikel).'" class="btn btn-primary btn-sm">Read more</a>
      <br><br>
      </div>
      ';
    }
  }
}elseif ($type_admin == "ADMIN TP4") {
  foreach ($record as $r) {
  if ($r->kategori_artikel == "Tutorial TP4") {
      echo '
      <div class="col-sm-9">
      <h2>'.$r->judul_artikel.'</h2>
      <h5><span class="glyphicon glyphicon-time"></span> Post '.$r->tanggal_artikel.'</h5>
      <img src="'.base_url().'assets/images/foto_artikel/'.$r->foto.'" class="img-responsive" width="300" height="175" ="Image">
      <p>'.substr($r->isi_artikel,0,100).'...</p>
      <p><strong>Genre</strong> : <span class="label label-success">'.$r->kategori_artikel.'</span></p>
      <a href="Dashboard/detail/'.md5($r->id_artikel).'" class="btn btn-primary btn-sm">Read more</a>
      <br><br>
      </div>
      ';
    }
  }
}

 ?>
