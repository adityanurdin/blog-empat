<?php
date_default_timezone_set('Asia/Jakarta');
$date = date('Y-m-d h:i:s');

 ?>
<h2>New Post</h2>
<hr>
<!-- <form <?= form_open('Dashboard/new_post'); ?> -->
  <?= form_open_multipart('Dashboard/new_post') ?>
<div class="col-sm-8">
  <input type="text" value="<?= $date ?>" hidden="" name="tanggal_artikel">
  <input type="text" value="<?php echo $this->session->userdata('username'); ?>" hidden="" name="username">
<input type="text" class="form-control" placeholder="Judul Post"  name="judul_artikel" required="">
<br>
<?php
$type_admin = $this->session->userdata('type_admin');
if ($type_admin == "MASTER") {
  echo '
  <div>
    <select class="form-control" name="kategori_artikel" required="">
  ';
  foreach ($kategori as $k) {
    echo "<option value='$k->kategori'>$k->kategori</option>";
  }
  echo '
  </select>
</div>
<br>
  ';
}elseif ($type_admin == "ADMIN TKJ") {
    echo '<input type="text" name="kategori_artikel" hidden="" value="Tutorial TKJ">';
}elseif ($type_admin == "ADMIN TSM") {
  echo '<input type="text" name="kategori_artikel" hidden="" value="Tutorial TSM">';
}elseif ($type_admin == "ADMIN TP4") {
  echo '<input type="text" name="kategori_artikel" hidden="" value="Tutorial TP4">';
}
 ?>
<textarea id="ckeditor" class="form-control" rows="20" name="isi_artikel" required=""></textarea>
<br>
Gambar : <br>
<input type="file" name="userfile" size="20" />
Gambar tidak boleh melebihi 1Mb
<br>
<input type="checkbox" required=""> Im sure would like to upload this story
<br><br>
<button type="submit" name="submit" class="btn btn-primary">Post</button>
</form>
</div>
<table>
  <tr>
    <td>
<div class="col-sm-16">
  <!-- <h2>Tag line</h2>
  <div class="caption">
    <li><code>< isicode ></code>isi text<code>< / isicode ></code>(tanpa spasi)</li>
    <li><code> b </code> Untuk Menebalkan Tulisan</li>
    <li><code> i </code> Untuk Memiringkan Tulisan</li>
    <li><code> u </code> Untuk Menggaris Bawahi Tulisan</li>
    <li><code> br </code> Untuk Memberikan ENTER pada Text</li>
    <li><code> p </code> Untuk Membuat Paragraf Baru pada Text</li>
    <li><code> h1 - h6 </code> Untuk Memperbesar Tulisan </li> -->
    <!-- <li><input type="text" value="<br>"></li> -->
  </div>
  <hr>
  <h2>rules</h2>
  <div class="caption">
    <li>Perhatikan Bahasa yang di gunakan, harus sopan...</li>
    <li>Buat Judul semenarik mungkin</li>
    <li>Genre harus sesuai dengan isi artikel</li>
    <li>Clikbait diperbolehkan</li>
    <li>Buat cerita Semenarik mungkin</li>
  </div>
</div>
</td>
</tr>
</table>

<script>
var ckeditor = CKEDITOR.replace('ckeditor',{
                  height:'300px'
});

CKEDITOR.disableAutoInline = true;
CKEDITOR.inline('editable');
</script>
