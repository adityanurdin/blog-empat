<br><br>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
<div class="col-sm-8">
  <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search for title" title="Type in a name">
<br>
<table class="table" id="myTable">
    <thead>
      <tr>
        <th>Title</th>
        <th>Edit</th>
      </tr>
    </thead>
    <?php
    $type_admin = $this->session->userdata('type_admin');
    if ($type_admin == "MASTER") {
      foreach ($record as $r) {
        echo "
            <tbody>
              <tr>
                <td>$r->judul_artikel</td>
                <td><a href='".base_url()."Dashboard/edit_post/".md5($r->id_artikel)."' class='btn btn-warning btn-sm'>Edit</a></td>
              </tr>
            </tbody>
        </div>
        ";
        }
    }elseif ($type_admin == "ADMIN TKJ") {
      foreach ($record as $r) {
      if ($r->kategori_artikel == "Tutorial TKJ") {
        echo "
            <tbody>
              <tr>
                <td>$r->judul_artikel</td>
                <td><a href='".base_url()."Dashboard/edit_post/".md5($r->id_artikel)."' class='btn btn-warning btn-sm'>Edit</a></td>
              </tr>
            </tbody>
        </div>
        ";
        }
      }
    }elseif ($type_admin == "ADMIN TSM") {
      foreach ($record as $r) {
      if ($r->kategori_artikel == "Tutorial TSM") {
        echo "
            <tbody>
              <tr>
                <td>$r->judul_artikel</td>
                <td><a href='".base_url()."Dashboard/edit_post/".md5($r->id_artikel)."' class='btn btn-warning btn-sm'>Edit</a></td>
              </tr>
            </tbody>
        </div>
        ";
        }
      }
    }elseif ($type_admin == "ADMIN TP4") {
      foreach ($record as $r) {
      if ($r->kategori_artikel == "Tutorial TP4") {
        echo "
            <tbody>
              <tr>
                <td>$r->judul_artikel</td>
                <td><a href='".base_url()."Dashboard/edit_post/".md5($r->id_artikel)."' class='btn btn-warning btn-sm'>Edit</a></td>
              </tr>
            </tbody>
        </div>
        ";
        }
      }
    }

     ?>




<!-- <?php foreach ($record as $r) {
  echo "
      <tbody>
        <tr>
          <td>$r->judul_artikel</td>
          <td><a href='".base_url()."Dashboard/edit_post/".md5($r->id_artikel)."' class='btn btn-warning btn-sm'>Edit</a></td>
        </tr>
      </tbody>
  </div>
  ";
}

?> -->
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
