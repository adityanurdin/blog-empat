<?php
date_default_timezone_set('Asia/Jakarta');
$date = date('Y-m-d h:i:s');

 ?>

<h2>Edit Post</h2>
<hr>
<form <?= form_open('Dashboard/edit_post'); ?>
<div class="col-sm-8">
  <input type="text" value="<?= $date ?>" hidden="" name="tanggal_artikel">
  <input type="text" value="<?= $record['id_artikel'] ?>" hidden="" name="id_artikel">
<input type="text" class="form-control"  value="<?= $record['judul_artikel'] ?>" name="judul_artikel" placeholder="Judul Artikel">
<br><?php
$type_admin = $this->session->userdata('type_admin');
if ($type_admin == "MASTER") {
  echo '
  <div>
    <select class="form-control" name="kategori_artikel" required="">
  ';
  foreach ($kategori as $k) {
    echo "<option value='$k->kategori'>$k->kategori</option>";
  }
  echo '
  </select>
</div>
<br>
  ';
}elseif ($type_admin == "ADMIN TKJ") {
    echo '<input type="text" name="kategori_artikel" hidden="" value="Tutorial TKJ">';
}elseif ($type_admin == "ADMIN TSM") {
  echo '<input type="text" name="kategori_artikel" hidden="" value="Tutorial TSM">';
}elseif ($type_admin == "ADMIN TP4") {
  echo '<input type="text" name="kategori_artikel" hidden="" value="Tutorial TP4">';
}
 ?>
<textarea id="ckeditor" class="form-control" rows="20" placeholder="Isi Artikel" name="isi_artikel" ><?= $record['isi_artikel'] ?></textarea>
<br>
<input type="submit" name="submit" value="Edit" class="btn btn-warning">
</form>
<a href="" disable="" class="btn btn-success">import .Docx</a>
</div>
<table>
  <tr>
    <td>
<div class="col-sm-16">
  <!-- <h2>Tag line</h2>
  <div class="caption">
    <li><code> b </code> Untuk Menebalkan Tulisan</li>
    <li><code> i </code> Untuk Memiringkan Tulisan</li>
    <li><code> u </code> Untuk Menggaris Bawahi Tulisan</li>
    <li><code> br </code> Untuk Memberikan ENTER pada Text</li>
    <li><code> p </code> Untuk Membuat Paragraf Baru pada Text</li>
    <li><code> h1 - h6 </code> Untuk Memperbesar Tulisan </li>
  </div>
  <hr> -->
  <h2>rules</h2>
  <div class="caption">
    <li>Perhatikan Bahasa yang di gunakan, harus sopan...</li>
    <li>Buat Judul semenarik mungkin</li>
    <li>Genre harus sesuai dengan isi artikel</li>
    <li>Clikbait diperbolehkan</li>
    <li>Buat cerita Semenarik mungkin</li>
  </div>
</div>
</td>
</tr>
</table>
<script>
var ckeditor = CKEDITOR.replace('ckeditor',{
                  height:'300px'
});

CKEDITOR.disableAutoInline = true;
CKEDITOR.inline('editable');
</script>
</body>
