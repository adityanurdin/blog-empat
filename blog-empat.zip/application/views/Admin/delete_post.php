<?php
$type_admin = $this->session->userdata('type_admin');
if ($type_admin == "MASTER") {
  echo '

  <br><br>
  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModal">DELETE ALL POST</button>

  <!-- Modal -->
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">WARNING!!!</h4>
        </div>
        <div class="modal-body">
          <form  '.form_open("Dashboard/delete_all").'
          <p>This action will delete all your post!!!</p>
          <input type="checkbox" required=""> I am sure with what I do
        </div>
        <div class="modal-footer">
          <button type="submit" name="submit" class="btn btn-danger">Im Sure</button>
        </form>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>

  ';
}
  ?>


<br><br><br>
<div class="col-sm-8">
  <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search for title" title="Type in a name">
<br>
<table class="table" id="myTable">
    <thead>
      <tr>
        <th>Title</th>
        <th>Delete</th>
      </tr>
    </thead>

    <?php
    $type_admin = $this->session->userdata('type_admin');
    if ($type_admin == "MASTER") {
      foreach ($record as $r) {
        echo "
        <tbody>
          <tr>
            <td>$r->judul_artikel</td>
            <td><a href='".base_url()."Dashboard/delete_post/".$r->id_artikel."' class='btn btn-danger btn-sm'>Delete</a></td>
          </tr>
        </tbody>
    </div>
    ";
        }
    }elseif ($type_admin == "ADMIN TKJ") {
      foreach ($record as $r) {
      if ($r->kategori_artikel == "Tutorial TKJ") {
        echo "
        <tbody>
          <tr>
            <td>$r->judul_artikel</td>
            <td><a href='".base_url()."Dashboard/delete_post/".$r->id_artikel."' class='btn btn-danger btn-sm'>Delete</a></td>
          </tr>
        </tbody>
    </div>
    ";
        }
      }
    }elseif ($type_admin == "ADMIN TSM") {
      foreach ($record as $r) {
      if ($r->kategori_artikel == "Tutorial TSM") {
        echo "
        <tbody>
          <tr>
            <td>$r->judul_artikel</td>
            <td><a href='".base_url()."Dashboard/delete_post/".$r->id_artikel."' class='btn btn-danger btn-sm'>Delete</a></td>
          </tr>
        </tbody>
    </div>
    ";
        }
      }
    }elseif ($type_admin == "ADMIN TP4") {
      foreach ($record as $r) {
      if ($r->kategori_artikel == "Tutorial TP4") {
        echo "
        <tbody>
          <tr>
            <td>$r->judul_artikel</td>
            <td><a href='".base_url()."Dashboard/delete_post/".$r->id_artikel."' class='btn btn-danger btn-sm'>Delete</a></td>
          </tr>
        </tbody>
    </div>
    ";
        }
      }
    }

     ?>



<!-- <?php foreach ($record as $r) {
  echo "
      <tbody>
        <tr>
          <td>$r->judul_artikel</td>
          <td><a href='".base_url()."Dashboard/delete_post/".$r->id_artikel."' class='btn btn-danger btn-sm'>Delete</a></td>
        </tr>
      </tbody>
  </div>
  ";
}

?> -->
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
