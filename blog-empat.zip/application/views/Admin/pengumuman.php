<?php
date_default_timezone_set('Asia/Jakarta');
$date = date('Y-m-d h:i:s');

 ?>
<div class="alert alert-success">
  <strong>Success!</strong> Indicates a successful or positive action.
</div>
<center>
    <!-- Trigger the modal with a button -->
    <button class="btn btn-danger">Hapus Pengumuman</button>
    <br><br>
 <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Buat Pengumuman</button>
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Pengumuman</h4>
        </div>
        <div class="modal-body">
          <?= form_open('Dashboard/pengumuman') ?>
          <div class="form-group">
              <input type="text" value="<?= $date ?>" hidden="" name="tgl_pengumuman">
            <textarea class="form-control" rows="3" name="pengumuman"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" name="submit" class="btn btn-default" >Submit</button>
        </form>
        </div>
      </div>
