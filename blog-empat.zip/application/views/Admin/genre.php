<br><br>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
<div class="col-sm-8">
  <div class="col-sm-6">
  <form <?= form_open('Dashboard/genre'); ?>
    <?php

    $type_admin = $this->session->userdata('type_admin');
    if ($type_admin == "MASTER") {
      echo '
      <input type="text" class="form-control" placeholder="Add Genre" name="kategori">
    </div>
      <button type="submit" name="submit" class="btn btn-primary">Add Genre</button>
    </form>
      <br><br>
      <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search for Genre" title="Type in a name">
    <br>
    <table class="table" id="myTable">
        <thead>
          <tr>
            <th>Genre</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
      ';
      foreach ($record as $r) {
        echo "
            <tbody>
              <tr>
                <td>$r->kategori</td>
                <td><a href='".base_url()."Dashboard/edit_post/".$r->id_kategori."' class='btn btn-warning btn-sm'>Edit</a></td>
                <td><a href='".base_url()."Dashboard/edit_post/".$r->id_kategori."' class='btn btn-danger btn-sm'>Delete</a></td>
              </tr>
            </tbody>
        </div>
        ";
      }
    }else {
      echo "<center><h1>ACCESS DENIED !!</h1></center>";
    }

     ?>
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
