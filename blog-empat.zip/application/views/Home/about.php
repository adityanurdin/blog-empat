<div class="col-sm-9">
<h1>About</h1>
<!-- <hr>
Halo guys, nama gua muhammad aditya nurdin biasa di panggil adit sama keluarga ataupun temen - temen di kelas, di rumah, dan dimana pun lah pokonya.Gua berasal dari bekasi sekolah gua di <strong>SMK N 4 BEKASI</strong> dan sekarang gua duduk di bangku kelas 3, alesan gua ngebuat blog ini adalah karna gua terinspirasi dari idola gua yaitu <strong>Gitasavitri&nbsp;</strong>yang cantik bgt dan insyaallah solehah aamiin..., Saat pertama kali gua liat blog dia itu gua lgsung suka karna kesederhanaan blog nya dan konten blog nya yg asik dan mengedukasi. Dia ngasih tau gmn dia Kuliah di jerman, gmn dia tinggal di jerman dan lain - lain lah pokonya.</p>

<p>Gua yang membangun sendiri website ini dari 0 hingga jadi seperti sekarang ini, gua di bantu sama temen - temen line square gua, nama line square nya Codeigniter Forum ID kalo kalian mau join silahkan aja di sana orang nya baik - baik terutama bang Gilang Pratama yang selalu jawab pertanyaan gua.</p>

<p>Design nya web ini gua belajar dari w3school.com gua belajar bootstrapnya di situ dan css nya.Makasih buat semua yg terlibat dalam pembuatan ini banyak bgt web yang gua kunjungin untuk mengembangkan web ini sampai seperti ini, makasih juga buat kalian yang udh mau baca - baca atau pun hanya sekedar berkunjung di blog gua. Salam kenal dari gua....</p>
</p> -->
<hr>
<br>
<h3>
  Created by Adityanurdin
  <br><br>
  For more information :
  <br>
  <li><a href="https://www.instagram.com/aditya252/">@aditya252(instagram)</a></li>
  <li><a href="https://web.facebook.com/adityanurdin0">adityanurdin0(facebook)</a></li>
  <li>ID LINE : adityanurdin</a></li>
</h3>

</div>
