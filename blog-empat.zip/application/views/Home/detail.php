<?php
if ($record['foto'] == NULL) {
  echo "
<div class='col-sm-9'>
      <h1>".$record['judul_artikel']."</h1>
      <p><strong>Genre</strong> : <span class='label label-success'>".$record['kategori_artikel']."</span></p>
      <h5><span class='glyphicon glyphicon-time'></span> Post ".$record['tanggal_artikel']."</h5>
      <p>".$record['isi_artikel']."</p>
      <hr>
      <br><br>
      <div class='fb-comments' data-href='http://blog-empat.000webhostapp.com/Index/detail/".md5($record['id_artikel'])."' data-numposts='5'></div>
      </div>
";
}else {
  echo "
<div class='col-sm-9'>
      <h1>".$record['judul_artikel']."</h1>
      <p><strong>Genre</strong> : <span class='label label-success'>".$record['kategori_artikel']."</span></p>
      <h5><span class='glyphicon glyphicon-time'></span> Post ".$record['tanggal_artikel']."</h5>
      <img src='".base_url()."assets/images/foto_artikel/".$record['foto']."' class='img-responsive'  width='300' height='175' alt='Image'>
      <br>
      <p>".$record['isi_artikel']."</p>
      <p>Artikel By : ".$record['username']."</p>
      <hr>
      <br><br>
   <script src='//www.powr.io/powr.js?external-type=html'></script>
 <div class='powr-reviews' id='".md5($record['id_artikel'])."'></div>
      </div>
";
}

 ?>

<!-- <div class="col-sm-4">
<form>
  <input type="number" value="<?= $record['id_artikel'] ?>" hidden="" name="id_artikel">
  <input type="text" name="username" placeholder="Nickname" class="form-control">
  <br>
  <textarea id="ckeditor" class="form-control" rows="5" name="komen" placeholder="Comment" required=""></textarea>
  <br>
  <button type="submit" name="submit" class="btn btn-success">Send</button>
</div> -->
<!-- <p><strong>
Terimakasih buat kalian yang udah mau menyempatkan baca cerita di blog gue,
jangan lupa buat baca - baca cerita yang lain juga ya.
Jangan lupa juga buat subscribe blog gua biar kalian bisa dapet informasi seputar blog
gue di email kalian :)
</strong></p> -->
<!--<div class='fb-comments' data-href='http://blog-empat.000webhostapp.com/Index/detail/".md5($record['id_artikel'])."' data-numposts='5'></div>-->
