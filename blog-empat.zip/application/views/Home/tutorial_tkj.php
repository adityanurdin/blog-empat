  <div class='col-sm-9'>
  <hr>
  <h5>TUTORIAL TKJ</h5>
  <hr>
  <!-- <input type="text" id="myInput" class="form-control" onkeyup="myFunction()" placeholder="Search"> -->
  <script>
  (function() {
    var cx = '016790428839202640919:muaqhdimvc8';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
<gcse:search></gcse:search>
  <?php foreach ($record as $r) {
    if ($r->kategori_artikel == "Tutorial TKJ") {
      if ($r->foto == NULL) {
        echo "
        <div class='col-sm-9'>
        <table class='table' id='myTable'>
        <h2>$r->judul_artikel</h2>
        <h5><span class='glyphicon glyphicon-time'></span> Post $r->tanggal_artikel</h5>
        <p>".substr($r->isi_artikel,0,150)."...</p>
        <p><strong>Genre</strong> : <span class='label label-success'>$r->kategori_artikel</span></p>
        <a href='".base_url()."Index/detail/".md5($r->id_artikel)."' class='btn btn-primary btn-sm'>Read more</a>
        <br><br>
        </table>
        </div>
        ";
      } else {
        echo "
        <div class='col-sm-9'>
        <table class='table' id='myTable'>
        <h2>$r->judul_artikel</h2>
        <h5><span class='glyphicon glyphicon-time'></span> Post $r->tanggal_artikel</h5>
        <img src='".base_url()."assets/images/foto_artikel/".$r->foto."' class='img-responsive'  width='300' height='175' alt='Image'>
        <p>".substr($r->isi_artikel,0,150)."...</p>
        <p><strong>Genre</strong> : <span class='label label-success'>$r->kategori_artikel</span></p>
        <a href='".base_url()."Index/detail/".md5($r->id_artikel)."' class='btn btn-primary btn-sm'>Read more</a>
        <br><br>
        </table>
        </div>
        ";
      }
    }
  } ?>
</div>
<script>
function myFunction() {
    // Declare variables
    var input, filter, div, p, a, i;
    input = document.getElementById('myInput');
    filter = input.value.toUpperCase();
    div = document.getElementById("myUL");
    p = ul.getElementsByTagName('li');

    // Loop through all list items, and hide those who don't match the search query
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}
</script>
