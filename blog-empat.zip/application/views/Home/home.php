<?php foreach ($record as $r) {
  if ($r->foto == NULL) {
    echo "
    <div class='col-sm-9'>
          <h2>$r->judul_artikel</h2>
          <h5><span class='glyphicon glyphicon-time'></span> Post $r->tanggal_artikel</h5>
            <p>Artikel By : $r->username</p>
          <p>".substr($r->isi_artikel,0,150)."...</p>
          <p><strong>Genre</strong> : <span class='label label-success'>$r->kategori_artikel</span></p>
          <a href='".base_url()."Index/detail/".md5($r->id_artikel)."' class='btn btn-primary btn-sm'>Read more</a>
          <br><br>
          </div>


    ";
  }else {
    echo "
    <div class='col-sm-9'>
          <h2>$r->judul_artikel</h2>
          <h5><span class='glyphicon glyphicon-time'></span> Post $r->tanggal_artikel</h5>
            <p>Artikel By : $r->username</p>
          <img src='".base_url()."assets/images/foto_artikel/".$r->foto."' class='img-responsive'  width='300' height='175' alt='Image'>
          <p>".substr($r->isi_artikel,0,150)."...</p>
          <p><strong>Genre</strong> : <span class='label label-success'>$r->kategori_artikel</span></p>
          <a href='".base_url()."Index/detail/".md5($r->id_artikel)."' class='btn btn-primary btn-sm'>Read more</a>
          <br><br>
          </div>


    ";
  }

}
?>
<br>
<div class='col-sm-9'>
  <center><?= $paging ?></center>
</div>
